# Repeated CSS Grid

For this assignment we're going to create a grid that we can reuse as many times as we need to depending on how many products we have. 

![Assignment Three](images/assignment_three.png)

If you want more of a challenge try creating an alternating grid so that every other product gets a new grid style. 
