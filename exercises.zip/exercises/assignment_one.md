# Basic CSS Grid page

In this assignment we're going to use the properties we learned in the previous lesson to build a simple site. It's one that we could easily build without css grid but here we'll see the simplicity with with we can built it. 

![alt text](images/assignment_one.jpg)

Remember you can use multiple divs that have the `display:grid;` property. In this scenario we have multiple layouts so we're going to need to have different divs that are using it so we can change the `grid-template-columns` layout. 