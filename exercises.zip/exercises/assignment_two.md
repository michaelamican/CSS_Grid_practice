# Broken grid layout

In this assignment we're going to use the properties we learned in the previous lesson to build a broken grid site. In order to complete this assignment think first about drawing out the grid and what it might look like. Once you have the grid then we can begin coding our site. 

![alt text](images/css_grid_assignment_two.jpg)
