# CSS Grid

## Creating complex layouts

Up until now we haven't done anything that we couldn't do without css grid. So let's take a look at some more complex scenarios. 

As we approach the design of what can be called a "broken grid" layout we have to change the way we think about the process. Up until now we have always approached our HTML and CSS understanding that the order that we place our elements on the page has an effect on how they will appear on the page. With CSS grid we're going to alter that. 

With CSS Grid we can define our grid and the sizes that each column and row will be. Once it's been defined we can start placing items directly on that grid by identifying how many rows and columns a specific item should take up. 

Let's take a look at an example so we can more clearly see how this works. 

![Sample Website](images/css_grid_example.png)

On this page we can see a simple example of a broken grid layout. Elements do not  have a clear columnar layout. Many of the elements seem to overlap columns. However, if we lay a grid on top of this image we'll be able to see how we can apply css grid to create this type of design. With css grid each column and row is numbered starting at 1. If we want something to take up the first three columns we would say it starts at 1 and ends at 4.

![Sample With Grid](images/css_grid_base.png)

Here we can start to see how customized our grids can become. We will build a somewhat simpiler example in a moment but let's look at what the code would look like to build this. 

FOr this example we will assume that there is a grid that has 11 columns and 11 rows of different heights and widths. 

We'll start with the picture of the oranges and assume our html looks something like this.

```html
<!-- The wrapper contains the grid -->
<div class="wrapper">
    <!-- The orange div is going to be placed onto the grid in a very specific location -->
    <div class="orange">
    </div>
</div>
```

```css
.orange{
    /* We want insert this into our grid where the 8th column starts */
    grid-column-start: 8;
    /* It should end where the 10th column starts */
    grid-column-end: 10;
    /* Similarily we want to start where the 6th row begins and end where the 11th row begins */
    grid-row-start: 6;
    grid-row-end: 11;
    /* This example is not complete */
    /* There would also be other properties here -- background image for example */
}
```

Here we've placed this picture of oranges in a very specific location within the grid. We've used four new css properites to achieve this. The value of each property can be thought of as the beginning of the column or row number. 

Let's take a look at another example by adding the gold background piece on the left side. First we'll add a div to the html. 

```html 
<div class="wrapper">
    <div class="orange">
    </div>
    <!-- Unlike before our could put the gold-back div above or below the ornage div and it wouldn't make a difference in the appearance of our page -->
    <div class="gold-back">
    </div>
</div>
```

Now we'll add in the css properties. If we look at our grid from earlier we can see that the columns should start at 1 and end at 7. The rows should start at 3 and end at 9. For this example we're going to show an alternative way of using these css properties. 

```css
.gold-back{
    /* Instead of using a start and stop we use this short hand that says col-start / col-end  */
    grid-column: 1 / 7;
    grid-row: 3 / 9;
    background-color: gold; /* We can use whatever color you want*/
}
```

The final piece of this example that we'll do is the cursive text. 

```html
<div class="wrapper">
    <div class="orange">
    </div>
    <div class="gold-back">
    </div>
    <div class="fancy-text">
        <!-- I have no idea what this actually means. -->
        <h1>Epicerie de Quartier</h1>
    </div>
</div>
```
```css
.fancy-text{
    grid-column: 3 / 5;
    grid-row: 2 / 4;
    font-family: cursive;
}
```

This will now place the text onto our grid in the correct spot which is partially overlapping our gold background. Next we will build a more simple example of a broken grid layout that you could use for a portfolio. 