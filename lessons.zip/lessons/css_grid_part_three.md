# Responsive Design and Dynamic Content with CSS Grid

## Responsive Design

### Media Queries

In order to understand how we will make our css grid responsive let's do a quick review of media queries. 

Within css we can control when certain css properties will be applied. For example if we want certain elements to disappear on smaller screens we could add the following code. 

```css
@media (max-width: 768px) {
    .item-to-hide{
        display:none;
    }
}
```

What this code says is for any screen that is less than 768px we want to hide that element. 

For the sake of this assignment we'll use the following breakpoints for our media queries. These are not the only options as you can make your breakpoints much more specific. 

```css
/* Small devices */
@media (max-width: 767px) { ... }

/* Medium devices (tablets, 768px and up) */
@media (min-width:778px) and (max-width: 991px) { ... }

/* Large devices (desktops, 992px and up). On this one we're using a min-width to say anything bigger than 992px should use these values. */
@media (min-width: 992px) { ... }
```

Here is a simple example of how we can apply this. Copy this code into your editor and open it up on a browser. Resize the window and see how the page responds. 

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Responsive Queries</title>
    <style>
        @media (max-width: 767px) {
            .main-text{
                color:purple;
                font-size:15px;
            }
        }

        @media (min-width:778px) and (max-width: 991px) {
            .main-text{
                color:orange;
                font-size:20px;
            }
         }

        @media (min-width: 992px) {
            .main-text{
                color:green;
                font-size:25px;
            }
        }
    </style>
</head>
<body>
    <h1 class="main-text">Hello CSS Grid</h1>
</body>
</html>
```

As you can see as we resize our broswer the font size and color of our text will change. This is happening because our css is changing depending on the width of the browser. We're going to use these principles in order to create a responsive css grid.


### CSS Grid with Media Queries

Let's now begin to incorporate media queries into our css grid. This is the page that we are going to be creating here. 

![Example Image](images/css_grid_three.png)

I've added the images in the sample code section but you can pick any pictures you would like. To start I'm going to give you the html code. There will be comments to help you understand but there shouldn't be anything here that is unfamiliar. 

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>CSS Grid</title>
    <!-- I've grabbed a font from google so that we're not using the default -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
    <link rel="stylesheet" href="test.css">
</head>
<body>
    <!-- The Wrapper is going to be what "wraps" the whole page.  -->
    <div class="wrapper">
        <!-- The left div will show part of the picture and be aligned with the left side -->
        <div class="left">
            <img src="images/3.jpeg">
        </div>

        <!-- The center div will display the main image -->
        <div class="center">
            <img src="images/2.jpeg" alt="">
        </div>

        <!-- The right div wil show part of the next picture and be aligned with the right side -->
        <div class="right">
            <img src="images/1.jpeg" alt="">
        </div>

        <!-- The text box will show some piece of information about the main center image -->
        <div class="text-box">
            <h2>Product Name One</h2>
        </div>
    </div>
</body>
</html>
```

The css is where the magic happens. We're going to have 4 different sections in our css. The first will be for properties that we want to add for all screen sizes. Background colors and font types are a few examples of things that won't change depending on the screen size. The next three sections will be the different properties that we want to change depending on the screen size of the user who is viewing our page.

Be sure to read through the comments to understand what is happening.

```css
<!-- CSS Resets -->
*{
    padding: 0;
    margin:0;
    font-family: 'Open Sans', sans-serif;
}
.wrapper{
    /* Remember this property is necessary for our grid template to work */
    display:grid;
    height:100vh;
    width:100%;
    background:#f3f3f3;
}
.text-box h2{
        padding:10%;
        margin:10%;
        border:1px solid black;
    }
/* This section will be used for small screens. (We will ignore this for now) */
@media (max-width: 767px) {
    .wrapper{

    }
}

/* This section will be used for medium screens. (We will ignore this for now) */
@media (min-width:778px) and (max-width: 991px) {
    .wrapper{

    }
}

/* This section will be used for large screens */
@media (min-width: 992px) {
    /* Once again we are using the grid template to define how many rows and columns we are going to have. */
    .wrapper{
        /* For this grid you can play around with how many rows and columns to use */
        /* We are splitting this up into 5 rows. */
        grid-template-rows: 1fr 1fr .75fr .25fr 1fr;
        /* We are splitting this into 8 columns */
        grid-template-columns:20% 2.5% 2.5% 15% 35% 2.5% 2.5% 20%;
    }
    /* In this design all of our content is going to be vertically aligned so we an apply those properties all at once.  */
    .left, .right, .center{
        grid-row: 2 / 5;
        overflow: hidden;
    }
    .left{
        /* The left side should start at the far left most column (the 1 spot) and go until the beginning of the second column. */
        grid-column:1 / 2;
    }
    .center{
        /* The center takes up two columns from 4 until 6 */
        grid-column: 4 / 6;
    }
    .right{
        /* The right takes up a single column on the far right most side. */
        grid-column:8 / 9;
    }
    img{
        height:100%;
        width:inherit;
    }
    .text-box{
        /* We made a few variations in the way our grid was set up so that we could make this box sit on top of the main image. */
        grid-column: 3 / 5;
        grid-row: 3 / 4;
        background:#f9f9f9;
        text-align: center;
        box-shadow: 0px 0px 15px -5px rgb(88, 87, 87);
    }
}
```

*If you inspect your code in firefox and click on the element who has the `display:grid` property, you can click on css property and a grid like this should pop up.*

In this display we can clearly see how our page has been layed out. 

![Grid Display](images/large_css_grid.png)

Let's try to resize our browser now. What's going to happen is that as soon as we hit the middle size media query we will loose the structure of our page. Let's go ahead and use the second media query to alter our grid for medium size

Within a medium sized screen we shouldn't need too many changes. So let's simple rearrange the size of the columns. Everything else we should be able to copy over. 

```css
/* This section will be used for medium screens */
@media (min-width:778px) and (max-width: 991px) {
    .wrapper{
        grid-template-rows: 1fr 1fr .75fr .25fr 1fr;
        /* All the changes that we made for the medium size happen here. We simple took 10% off of the first and last column and added them to the middle section so it would take a more prominent role on smaller screens. */
        grid-template-columns:10% 2.5% 2.5% 25% 45% 2.5% 2.5% 10%;
    }
    .left, .right, .center{
        grid-row: 2 / 5;
        overflow: hidden;
    }
    .left{
        grid-column:1 / 2;
    }
    .center{
        grid-column: 4 / 6;
    }
    .right{
        grid-column:8 / 9;
    }
    img{
        height:100%;
        width:inherit;
    }
    .text-box{
        grid-column: 3 / 5;
        grid-row: 3 / 4;
        background:#f9f9f9;
        text-align: center;
        box-shadow: 0px 0px 15px -5px rgb(88, 87, 87);
    }
    
}
```

![Grid Display](images/medium_css_grid.png)

As we resize our screen we can see that our new sizing scheme will being once we hit the media query breakpoint. 

Let's go ahead and finish this off by making some changes on the smallest screen sizes. 

```css
/* This section will be used for small screens */
@media (max-width: 767px) {
    .wrapper{
        /* Here we change the size of the rows and columns to fit a smaller screen  */
        grid-template-rows: 2fr 1.25fr .75fr .25fr 2fr;
        grid-template-columns:10% 2.5% 2.5% 50% 20% 2.5% 2.5% 10%;
    }
    .left, .right, .center{
        grid-row: 2 / 5;
        overflow: hidden;
    }
    .left{
        grid-column:1 / 2;
    }
    .center{
        grid-column: 4 / 6;
    }
    .right{
        grid-column:8 / 9;
    }
    img{
        height:100%;
        width:inherit;
    }
    .text-box{
        grid-column: 2 / 5;
        grid-row: 3 / 4;
        background:#f9f9f9;
        text-align: center;
        box-shadow: 0px 0px 15px -5px rgb(88, 87, 87);
    }
}
```
At this point we should now be able to resize our screen and see the changes that happen at each breakpoint. 

## Dynamic Content

Up until now we've created a page that looks nice but as pretty as it is it's unlikely that we'll ever have a page that uses just a single image. So let's look at how we can add a variable amount of content and still utilize our grid. In this section we're going to be using javascript and more specifically jQuery. I won't go too in depth about any of the JS code but simply use it as an example to show how we can use this is in more real world applications. 

In this example we're going to assume that we've looped through some information from our database and are printing our products onto our page one at a time. We would end up with something like this. Here we have four items, although it could be any number, each one is hidden by default. 

```html
<div class="wrapper">
    <div class="product hidden">
        <img src="images/3.jpeg">
    </div>
    <div>
        <h2>Product Name One</h2>
    </div>

    <div class="product hidden">
        <img src="images/2.jpeg" alt="">
    </div>
    <div>
        <h2>Product Name Two</h2>
    </div>

    <div class="product hidden">
        <img src="images/1.jpeg" alt="">
    </div>
    <div class="hidden">
        <h2>Product Name Three</h2>
    </div>

    <div class="product hidden">
        <img src="images/4.jpeg" alt="">
    </div>
    <div class="hidden">
        <h2>Product Name Four</h2>
    </div>


</div>
```

The only addition to css is as follows. 

```css
/* This can be added anywhere within your css */
.hidden{
    /* Anything with this class will not show up on our page. */
    display:none;
}
.right:hover, .left:hover{
    /* When we hover over the left of right image we should change the cursor so the user understands that they can click it. */
    cursor:pointer;
}
```

Now let's add in our Javscript. Here we are simply adding classes dynamically to control which divs are being added into our grid. 

```js
function startup(){
    // This function is in charge of getting our page set up initially. 
    // Here we are grabbing all of the elements that have a class of product so we know what we're dealing with
    var my_products = $('.product').toArray();
    if (my_products.length > 0) {
        setCenter(my_products, 0);
    }
    if (my_products.length == 2) {
        setRight(my_products, 1);
    }
    if (my_products.length > 2) {
        setRight(my_products, 1);
        setLeft(my_products, my_products.length - 1)
    }
}
// This calls the startup function so our page intializes correctly
startup();


function setCenter(arr, idx){
    // The setCenter functions takes the array of elements with the product class and the idx of the element that should be set to the center.
    // We start by removing the center class from the element that is currently occupying that location
    $('.center').removeClass('center');
    // We start by adding the center class to this element so it will occupy the correct place
    let item = $(arr[idx])
    item.addClass('center').removeClass('hidden');
    // Here we ensure that the text that goes with this specific product gets unhidden so it will display correctly. 
    item.next('div').addClass('text-box').removeClass('hidden');
}
function setLeft(arr, idx){
    // The setLeft function operates almost identically to the setCenter. We'll grab this specific element and move it into the "left" position on our css grid
    $('.left').removeClass('left');
    let item = $(arr[idx])
    item.addClass('left').removeClass('hidden');
    item.next('div').addClass('hidden');
}
function setRight(arr, idx){
    $('.right').removeClass('right');
    let item = $(arr[idx])
    item.addClass('right').removeClass('hidden');
    item.next('div').addClass('hidden');
}

$('.wrapper').on('click', '.right', function(){
    // This function will call the setCenter, setRight, and setLeft functions based off of which element is currently on the right 
    let r_idx = $('.product').index($(this));
    let arr = $('.product').toArray()
    if(r_idx == 1){
        $(arr[arr.length - 1]).addClass('hidden');
    }else if(r_idx == 0){
        $(arr[arr.length - 2]).addClass('hidden');
    }else{
        $(arr[r_idx - 2]).addClass('hidden');
    }
    setCenter(arr, r_idx);
    if(r_idx == 0){
        setLeft(arr, arr.length - 1);
    }else{
        setLeft(arr, r_idx -1);
    }
    if(r_idx + 1 == arr.length){
        setRight(arr, 0);
    }else{
        setRight(arr, r_idx + 1);
    }
});

$('.wrapper').on('click', '.left', function(){
    // This function will call the setCenter, setRight, and setLeft functions based off of which element is currently on the left 
    let l_idx = $('.product').index($(this));
    let arr = $('.product').toArray()
    if (l_idx == arr.length - 1) {
        $(arr[1]).addClass('hidden');
    } else if (l_idx == arr.length - 2) {
        $(arr[0]).addClass('hidden');
    } else {
        $(arr[l_idx + 2]).addClass('hidden');
    }
    setCenter(arr, l_idx);
    if(l_idx == arr.length -1){
        setRight(arr, 0);
    }else{
        setRight(arr, l_idx + 1);
    }
    if(l_idx == 0){
        setLeft(arr, arr.length - 1);
    }else{
        setLeft(arr, l_idx - 1);
    }
})
```

This represents a more real world example of how we can utilize css grid to showcase all of our great products. It could also be used to show off all of your projects ;). 

