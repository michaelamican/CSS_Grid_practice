# CSS Grid

## What is CSS grid?

Put simply, CSS grid alows us to make complex and responsive web pages more easily and with more uniformity across browsers. 

## Why use CSS grid? 

When we visit a website we expect to see a certain level of structure. Generally we know a navigation bar will be near the top, or maybe on the left side. Any sort of social feed will be centered on our page with sub-menus or advertisements flanking it. Previous to CSS grid there were a number of alternatives that had been used to attempt to solve the problem of uniform displays. These included tables, flexbox and even the float property. All of which had a certain level of feeling "hacked" together, especially when usings floats. 

## CSS Grid vs CSS Frameworks (Bootstrap, Foundation, Materialize, etc.)

Thanks to well thought out css frameworks like Bootstrap, Foundation, and others we were able to overcome many of these shortcomings. These frameworks create a grid system of 12 columns that can be used on elements to define how wide an element should be. For many use cases this provides a sufficient solution. The problem comes when we start using asymmetrical design, especially with broken grid design. The grid system no longer works for this style. We can use the position property to start manipulating elements to do some things but it isn't a perfect solution. It's in this specific situation that CSS Grid can shine. 

## Getting started

CSS grid is built using rows and columns. Unlike css frameworks these can be made up of any combination of rows and columns, with each having a width or height of our choosing. Meaning we can have a grid with 7 columns and 9 rows, or 12 columns and 1 row. We simply have to tell css what kind of layout we want. 

### Adding columns 

To start we're going to create a simple layout with three columns. We'll assume that our HTML and CSS files are correctly linked together. 

We start by creating a div that will serve as a "wrapper" around our elemnt. Inside we will add three more div's, each will have a unique class so we can color the background.

```html
<!-- index.html -->
<div class="wrapper">
    <div class="red"></div>
    <div class="green"></div>
    <div class="blue"></div>
</div>
```

Next we'll start creating our grid template. For this template each column we want gets a value. That value will represent the width that we want that specific column to take.

```css
/* styles.css */
.wrapper{
    /* We start by setting the display property to grid. */
    display:grid;
    /* This is going to create a template that has three columns that are 250px wide */
    grid-template-columns: 250px 250px 250px;
}
/* Basic styling for our page */
*{
    margin:0;
    padding:0;
}
.red, .green, .blue{
    height:100px;
}
.red{
    background:red;
}
.green{
    background:green;
}
.blue{
    background:blue;
}
```

If we open this up we should see three columns that are sitting next to each other. In our css we set display to grid and then used the `grid-template-columns` property to declare how many columns we want and how wide each should be. 

Obviously this current set up doesn't look great so what can we do to take up the full width? Let's change a couple properties in our css. 

```css
.wrapper{
    /* We now change each column to take up 1/3  of the width. */
    grid-template-columns: 33% 33% 33%;
}
```

While this looks better it still isn't taking up the full width. We could continue to add 3's on to each value to get it closer but there is a more elegant solution. With CSS grid we can now use `fr` as our measurement. The `fr` is a fraction unit, the width of the `fr` unit is based on the total number used in that specific row. Let's try this out by changed our css to the following. 

```css
.wrapper{
    grid-template-columns:1fr 1fr 1fr;
}
```

As you can see this will now split up each column evenly into thirds. If we switch it to `grid-template-columns:1fr 2fr 1fr;` the middle column would take up 50% while the left and right columns each take up 25%. 

### Adding rows

Let's start adding rows to make our design a little more complex. We're going to add a new `grid-template-rows` property into our css and double the number of div's that are sitting inside our wrapper element. 


```html
<div class="wrapper">
    <div class="red"></div>
    <div class="green"></div>
    <div class="blue"></div>
    <!-- The next three divs will serve as our second row -->
    <div class="red"></div>
    <div class="green"></div>
    <div class="blue"></div>
</div>
```

```css
.wrapper{
    display:grid;
    /* We have a three column layout with the middle column taking up 50% of the width. */
    grid-template-columns: 1fr 2fr 1fr;
    /* Similar to the columns we declare how many rows we want by setting the height of each row in our grid */
    grid-template-rows: 50px 100px;
}
```

*The height on the red, green, and blue class need to be removed for this to work*

When we refresh our page it will look like there is still only one row. In order to fix this we're going to use one more css property. The `grid-row-gap` property will allow us to specify how much of a gap we want to appear in between each row. Our css will now look like this. 

```css
.wrapper{
    display:grid;
    /* We have a three column layout with the middle column taking up 50% of the width. */
    grid-template-columns: 1fr 2fr 1fr;
    /* Our first row will be 50px tall and our second will be 100px; */
    grid-template-rows: 50px 100px;
    /* We want to have a 10px gap between each row. */
    grid-row-gap: 10px;
}
```

If we want to we can also add in a `grid-column-gap` to specify the space we want in between each column. We can also use `grid-grap` to add the same spacing between each column and row. Switch the earlier code to `grid-grap: 10px;` and see how your page changes. 
