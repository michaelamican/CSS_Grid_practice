function startup(){
    var my_products = $('.product').toArray();
    if (my_products.length > 0) {
        setCenter(my_products, 0);
    }
    if (my_products.length == 2) {
        setRight(my_products, 1);
    }
    if (my_products.length > 2) {
        setRight(my_products, 1);
        setLeft(my_products, my_products.length - 1)
    }
}
startup();

function setCenter(arr, idx){
    $('.center').removeClass('center');
    let item = $(arr[idx])
    item.addClass('center').removeClass('hidden');
    item.next('div').addClass('text-box').removeClass('hidden');
}
function setLeft(arr, idx){
    $('.left').removeClass('left');
    let item = $(arr[idx])
    item.addClass('left').removeClass('hidden');
    item.next('div').addClass('hidden');
}
function setRight(arr, idx){
    $('.right').removeClass('right');
    let item = $(arr[idx])
    item.addClass('right').removeClass('hidden');
    item.next('div').addClass('hidden');
}

$('.wrapper').on('click', '.right', function(){
    let r_idx = $('.product').index($(this));
    let arr = $('.product').toArray()
    if(r_idx == 1){
        $(arr[arr.length - 1]).addClass('hidden');
    }else if(r_idx == 0){
        $(arr[arr.length - 2]).addClass('hidden');
    }else{
        $(arr[r_idx - 2]).addClass('hidden');
    }
    setCenter(arr, r_idx);
    if(r_idx == 0){
        setLeft(arr, arr.length - 1);
    }else{
        setLeft(arr, r_idx -1);
    }
    if(r_idx + 1 == arr.length){
        setRight(arr, 0);
    }else{
        setRight(arr, r_idx + 1);
    }
});

$('.wrapper').on('click', '.left', function(){
    let l_idx = $('.product').index($(this));
    let arr = $('.product').toArray()
    if (l_idx == arr.length - 1) {
        $(arr[1]).addClass('hidden');
    } else if (l_idx == arr.length - 2) {
        $(arr[0]).addClass('hidden');
    } else {
        $(arr[l_idx + 2]).addClass('hidden');
    }
    setCenter(arr, l_idx);
    if(l_idx == arr.length -1){
        setRight(arr, 0);
    }else{
        setRight(arr, l_idx + 1);
    }
    if(l_idx == 0){
        setLeft(arr, arr.length - 1);
    }else{
        setLeft(arr, l_idx - 1);
    }
})